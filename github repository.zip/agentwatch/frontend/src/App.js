import { useState, useRef } from "react";

const typeColors = {
  intent: "#60a5fa",
  action: "#4ade80",
  suspicious: "#facc15",
  deviation_check: "#f97316",
  ALERT: "#ef4444",
  complete: "#4ade80",
};

export default function App() {
  const [logs, setLogs] = useState([]);
  const [status, setStatus] = useState("idle");
  const [alert, setAlert] = useState(null);
  const [task, setTask] = useState("Find cheapest flight to Mumbai and book it");
  const logEndRef = useRef(null);

  const startAgent = () => {
    setLogs([]);
    setAlert(null);
    setStatus("running");

    const source = new EventSource(
      `http://localhost:8000/run-agent?task=${encodeURIComponent(task)}`
    );

    source.onmessage = (e) => {
      const data = JSON.parse(e.data);
      setLogs((prev) => [...prev, data]);

      if (data.type === "ALERT") {
        setAlert(data);
        setStatus("frozen");
        source.close();
      }

      if (data.type === "complete") {
        setStatus("safe");
        source.close();
      }
    };

    source.onerror = () => {
      source.close();
      setStatus("idle");
    };
  };

  const statusStyle = {
    padding: "0.5rem 1rem",
    borderRadius: "8px",
    marginBottom: "1.5rem",
    background:
      status === "frozen" ? "#450a0a" :
      status === "running" ? "#1a2744" :
      status === "safe" ? "#052e16" : "#1a1a1a",
    border: `1px solid ${
      status === "frozen" ? "#dc2626" :
      status === "running" ? "#2563eb" :
      status === "safe" ? "#16a34a" : "#333"
    }`
  };

  return (
    <div style={{ background: "#0a0a0a", minHeight: "100vh", color: "white", fontFamily: "monospace", padding: "2rem" }}>

      {/* Header */}
      <div style={{ marginBottom: "2rem", display: "flex", alignItems: "center", gap: "1rem" }}>
        <div>
          <h1 style={{ fontSize: "2rem", color: "#60a5fa", margin: 0 }}>🛡️ AgentWatch</h1>
          <p style={{ color: "#6b7280", margin: "0.25rem 0 0 0" }}>Runtime Behavioral Watchdog for AI Agents</p>
        </div>
        <div style={{ marginLeft: "auto", background: "#1a1a2e", border: "1px solid #a78bfa", borderRadius: "8px", padding: "0.4rem 0.8rem", fontSize: "0.75rem", color: "#a78bfa" }}>
          ⚡ Powered by ArmorIQ Intent Enforcement
        </div>
      </div>

      {/* Task Input */}
      <div style={{ marginBottom: "1rem", display: "flex", gap: "1rem" }}>
        <input
          value={task}
          onChange={(e) => setTask(e.target.value)}
          style={{ flex: 1, padding: "0.75rem", background: "#1a1a1a", border: "1px solid #333", color: "white", borderRadius: "8px", fontFamily: "monospace" }}
        />
        <button
          onClick={startAgent}
          disabled={status === "running"}
          style={{ padding: "0.75rem 2rem", background: status === "running" ? "#333" : "#2563eb", color: "white", border: "none", borderRadius: "8px", cursor: "pointer", fontSize: "1rem" }}
        >
          {status === "running" ? "Running..." : "▶ Run Agent"}
        </button>
      </div>

      {/* Status Bar */}
      <div style={statusStyle}>
        {status === "frozen" && "🚨 AGENT FROZEN — HIJACK DETECTED"}
        {status === "running" && "🔵 Agent running — monitoring behavior..."}
        {status === "safe" && "✅ Task completed safely"}
        {status === "idle" && "⚪ Idle — assign a task to begin"}
      </div>

      {/* Live Log Feed */}
      <div style={{ background: "#111", border: "1px solid #222", borderRadius: "8px", padding: "1rem", height: "300px", overflowY: "auto", marginBottom: "1.5rem" }}>
        <p style={{ color: "#444", marginBottom: "0.5rem", margin: "0 0 0.5rem 0" }}>— LIVE ACTIVITY FEED —</p>
        {logs.map((log, i) => (
          <div key={i} style={{ marginBottom: "0.4rem", fontSize: "0.85rem" }}>
            <span style={{ color: "#444" }}>[{i + 1}] </span>
            <span style={{ color: typeColors[log.type] || "#fff" }}>
              [{log.type?.toUpperCase()}]
            </span>
            {" "}
            <span style={{ color: "#ccc" }}>
              {log.content || log.detail || log.message || log.current_behavior || ""}
            </span>
          </div>
        ))}
        <div ref={logEndRef} />
      </div>

      {/* Forensic Diff Panel */}
      {alert && (
        <div style={{ background: "#1a0000", border: "2px solid #dc2626", borderRadius: "8px", padding: "1.5rem" }}>
          <h2 style={{ color: "#ef4444", marginBottom: "1rem", marginTop: 0 }}>🔬 FORENSIC DIFF — ATTACK REPORT</h2>
          <div style={{ display: "grid", gap: "0.75rem", fontSize: "0.9rem" }}>

            <div>
              <span style={{ color: "#6b7280" }}>Original Intent: </span>
              <span style={{ color: "#4ade80" }}>{alert.original_intent}</span>
            </div>

            <div>
              <span style={{ color: "#6b7280" }}>Detected Behavior: </span>
              <span style={{ color: "#f97316" }}>{alert.detected_behavior}</span>
            </div>

            <div>
              <span style={{ color: "#6b7280" }}>Hijack Point: </span>
              <span style={{ color: "#ef4444" }}>{alert.hijack_point}</span>
            </div>

            <div>
              <span style={{ color: "#6b7280" }}>Was About To Do: </span>
              <span style={{ color: "#ef4444" }}>{alert.about_to_do}</span>
            </div>

            <div>
              <span style={{ color: "#6b7280" }}>Deviation Reason: </span>
              <span style={{ color: "#facc15" }}>{alert.deviation_reason}</span>
            </div>

            {/* ArmorIQ Status */}
            <div style={{ marginTop: "0.5rem", padding: "0.75rem", background: "#0d0d1f", border: "1px solid #a78bfa", borderRadius: "6px" }}>
              <span style={{ color: "#a78bfa", fontWeight: "bold" }}>⚡ ArmorIQ Enforcement: </span>
              <span style={{ color: "#c4b5fd" }}>{alert.armoriq_status}</span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}