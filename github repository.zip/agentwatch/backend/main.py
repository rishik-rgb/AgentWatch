from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from agent import run_agent
import json
import time
import threading

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/run-agent")
def run_agent_stream(task: str = "Find cheapest flight to Mumbai and book it"):
    def event_stream():
        logs = []

        def log_callback(entry):
            logs.append(entry)

        thread = threading.Thread(target=run_agent, args=(task, log_callback))
        thread.start()

        sent = 0
        while thread.is_alive() or sent < len(logs):
            if sent < len(logs):
                yield f"data: {json.dumps(logs[sent])}\n\n"
                sent += 1
            time.sleep(0.3)

    return StreamingResponse(event_stream(), media_type="text/event-stream")